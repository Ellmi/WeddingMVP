<?php
/*
*	---------------------------------------------------------------------
*	This file create and contains the Playlist  post_type meta elements
*	---------------------------------------------------------------------
*/
add_action('init', 'tzplazart_create_playlist');
function tzplazart_create_playlist()
{
    $labels = array(
        'name'               => _x('Playlist', 'Playlist General Name', tz_plazart),
        'singular_name'      => _x('Playlist Item', 'Playlist Singular Name', tz_plazart),
        'add_new'            => _x('Add New', 'Add New Playlist', tz_plazart),
        'add_new_item'       => __('Add New Playlist', tz_plazart),
        'edit_item'          => __('Edit Playlist', tz_plazart),
        'new_item'           => __('New Playlist', tz_plazart),
        'view_item'          => __('View Playlist', tz_plazart),
        'search_items'       => __('Search Playlist', tz_plazart),
        'not_found'          => __('Nothing found', tz_plazart),
        'not_found_in_trash' => __('Nothing found in Trash', tz_plazart),
        'parent_item_colon'  => ''
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'query_var'          => true,
        //'menu_icon' => PLUGIN_PATH . '/plazart/assets/images/portfolio-icon.png',
        'rewrite'            => true,
        'capability_type'    => 'post',
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array('title'), //'editor', 'excerpt', 'comments',
        'rewrite'            => array('slug' => 'playlist', 'with_front' => false ),
        //'has_archive'        => 'portfolio'
    );
    register_post_type('playlist', $args);

}

