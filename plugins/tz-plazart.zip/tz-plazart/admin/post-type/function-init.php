<?php

$dir_pt = dirname( __FILE__ );
require_once $dir_pt . '/portfolio-post-type.php';
require_once $dir_pt . '/ourteam-post-type.php';
require_once $dir_pt . '/testimonials-post_type.php';
require_once $dir_pt . '/playlist.php';
?>