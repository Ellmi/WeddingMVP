<?php

    function tzeverline_shorttitle( $atts ){
        extract(shortcode_atts(array(
            'title' =>  ''
        ), $atts));
        ob_start();
    ?>
        <h3 class="everline_title"><?php echo esc_html($title); ?></h3>
    <?php
        $tzeverline  = ob_get_contents();
        ob_end_clean();
        return $tzeverline;
    }
    add_shortcode('tztitle','tzeverline_shorttitle');
?>