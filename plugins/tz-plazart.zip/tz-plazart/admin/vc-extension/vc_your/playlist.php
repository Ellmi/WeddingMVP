<?php
    function tzplazart_playlist( $atts ){
        extract(shortcode_atts(array(
            'title'     =>  '',
            'limit'     =>  6,
            'autoplay'  =>  1
        ), $atts));
        ob_start();
        wp_enqueue_script('jplayer');
        wp_enqueue_script('playlist');
    ?>
        <div class="tzmusic_playlist">
            <?php if ( isset( $title ) && !empty( $title ) ): ?>
                <h3 class="playlist_title">
                    <?php echo esc_html($title); ?>
                </h3>
            <?php endif; ?>
            <div id="jquery_jplayer_2" class="jp-jplayer"></div>
            <div id="jp_container_2" class="jp-audio" role="application" aria-label="media player">
                <div class="jp-type-playlist">
                    <div class="jp-gui jp-interface">
                        <div class="controls-progress">
                            <div class="jp-controls">
                                <button class="jp-previous" role="button" tabindex="0"><i class="fa fa-backward"></i></button>
                                <button class="jp-play" role="button" tabindex="0"><i class="fa fa-play"></i></button>
                                <button class="jp-pause" role="button"  tabindex="0"><i class="fa fa-pause"></i></button>
                                <button class="jp-next" role="button" tabindex="0"><i class="fa fa-forward"></i></button>
                                <button class="jp-stop" role="button" tabindex="0"><i class="fa fa-stop"></i></button>
                            </div>
                            <div class="jp-progress">
                                <div class="jp-seek-bar">
                                    <div class="jp-play-bar"></div>
                                </div>
                            </div>
                        </div>
                        <div class="jp-volume-controls">
                            <button class="jp-mute" role="button" tabindex="0">mute</button>
                            <button class="jp-volume-max" role="button" tabindex="0">max volume</button>
                            <div class="jp-volume-bar">
                                <div class="jp-volume-bar-value"></div>
                            </div>
                        </div>
                        <div class="jp-time-holder">
                            <div class="jp-current-time" role="timer" aria-label="time">&nbsp;</div>
                            <div class="jp-duration" role="timer" aria-label="duration">&nbsp;</div>
                        </div>
                        <div class="jp-toggles">
                            <button class="jp-repeat" role="button" tabindex="0">repeat</button>
                            <button class="jp-shuffle" role="button" tabindex="0">shuffle</button>
                        </div>
                    </div>
                    <div class="jp-playlist">
                        <ul>
                            <li>&nbsp;</li>
                        </ul>
                    </div>
                    <div class="jp-no-solution">
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
            //<![CDATA[
            jQuery(document).ready(function(){

                new jPlayerPlaylist({
                    jPlayer: "#jquery_jplayer_2",
                    cssSelectorAncestor: "#jp_container_2"
                }, [
                    <?php
                        $args = array(
                            'post_type' =>  'playlist',
                            'posts_per_page'     =>  $limit
                        );
                        $ip = 0;
                        $playlist_query = new WP_Query( $args );

                        if ( $playlist_query -> have_posts() ):
                           $coung_pl = count($playlist_query->posts);
                            while ( $playlist_query -> have_posts() ):
                            $playlist_query -> the_post();
                                $mp3 = get_post_meta( get_the_ID(), THEME_PREFIX . '_playlist_mp3', true );
                                $oga = get_post_meta( get_the_ID(), THEME_PREFIX . '_playlist_ogg', true );
                    ?>
                    {
                        title:"<?php the_title(); ?>",
                        mp3:"<?php echo esc_url($mp3); ?>",
                        oga:"<?php echo esc_url($oga); ?>"
                    <?php
                      if( $ip < $coung_pl ) {
                            echo '},';
                      } else {
                            echo '}';
                      }
                      $ip++;

                          endwhile;
                      endif;
                      wp_reset_postdata();
                  ?>
                ],
                <?php if( $autoplay == 1 ): ?>
                {
                    playlistOptions: {
                        autoPlay: true
                    }
                },
                <?php endif; ?>
                {
                    swfPath: "<?php echo esc_url(PLUGIN_PATH .'/js/jplayer') ; ?>",
                    supplied: "oga, mp3",
                    wmode: "window",
                    useStateClassSkin: true,
                    autoBlur: false,
                    smoothPlayBar: true,
                    keyEnabled: true
                });
            });
            //]]>
        </script>
    <?php
        $everline_content = ob_get_contents();
        ob_end_clean();
        return $everline_content;
    }
    add_shortcode('tzplaylist','tzplazart_playlist')

?>