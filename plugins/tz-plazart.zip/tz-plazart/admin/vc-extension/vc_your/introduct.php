<?php
    function tzplazart_introduct( $atts ) {
        extract(shortcode_atts(array(
            'title'     =>  '',
            'image'     =>  '',
            'description'   =>  ''
        ),$atts));
        ob_start();
    ?>
        <div class="tzintroduct">
            <h3><?php echo esc_html($title); ?></h3>
            <div class="tzintroduct-img">
            <?php echo wp_get_attachment_image($image,'full'); ?>
            </div>
            <p>
                <?php echo esc_html($description); ?>
            </p>
        </div>
    <?php $content_everline = ob_get_contents();
        ob_end_clean();
        return $content_everline;
    }
    add_shortcode('introduct', 'tzplazart_introduct');
?>