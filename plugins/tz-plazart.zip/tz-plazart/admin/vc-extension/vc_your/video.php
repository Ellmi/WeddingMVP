<?php
    // [video]

    function tzeverline_video( $atts ){

        extract( shortcode_atts(array(
            'title'             =>  '',
            'description'       =>  '',
            'image_background'  =>  '',
            'video_mp4'         =>  '',
            'video_ogg'         =>  '',
            'video_web'         =>  ''
        ), $atts) );
        ob_start();
    ?>
        <div class="tz-video">
            <div class="tz-video-content">
                <button class="tzautoplay"><i class="fa fa-video-camera"></i></button>
                <button class="tzpause"><i class="fa fa-pause"></i></button>
                <h3><?php echo esc_html($title); ?></h3>
                <p><?php echo esc_html($description); ?></p>
            </div>
            <div class="bg-video" style="background: url(<?php echo esc_url(wp_get_attachment_url( $image_background )); ?>) no-repeat  center center / cover  transparent !important;"></div>
            <video class="videoID">
                <source type="video/mp4" src="<?php echo esc_url($video_mp4); ?>" />
                <source type="video/ogg" src="<?php echo esc_url($video_ogg); ?>" />
                <source type="video/webm" src="<?php echo esc_url($video_web); ?>" />
            </video>
        </div>
    <?php
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
    }
    add_shortcode('everline_video', 'tzeverline_video');
?>