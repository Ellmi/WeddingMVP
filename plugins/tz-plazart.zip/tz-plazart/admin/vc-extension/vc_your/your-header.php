<?php

//[header]
function tzdekor_header( $atts ){
    extract( shortcode_atts( array(
        'header_option' =>  'header1',
        'logo'          =>  '',
        'title'         =>  ''
    ), $atts ) );
    ob_start();
        $header_class = '';

        switch( $header_option ):
            case 'header1':
                $header_class = 'tz-header1';
                break;
            case 'header2':
                $header_class = 'tz-header2';
                break;
            case 'header3':
                $header_class = 'tz-header3'; // if fix header3-fix
                break;
            case 'header4':
                $header_class = 'tz-header4';
                break;
            case 'header5':
                $header_class = 'tz-header5';
                break;
            default:
                $header_class = 'tz-header1';
                break;
        endswitch;

    ?>
    <header class="tz-header <?php echo esc_attr($header_class); ?>">
            <?php
                if( $header_option == 'header1' ):
            ?>
                <div class="wrapbox">
                    <div class="container">
                        <button data-target=".nav-collapse" class="btn-navbar tz_icon_menu" type="button">
                            <i class="fa fa-bars"></i>
                        </button>
                        <h3 class="tzlogo pull-left">
                            <a href="<?php echo get_home_url(); ?>" title="<?php bloginfo('name'); ?>">
                                <?php if( isset( $logo ) && !empty( $logo ) ): ?>
                                    <img src="<?php echo esc_url(wp_get_attachment_url( $logo )); ?>" alt="<?php bloginfo('name'); ?>">
                                <?php else: ?>
                                    <img src="<?php echo esc_url(PLUGIN_PATH.'images/Everline_logo.png'); ?>" alt="<?php bloginfo('name'); ?>">
                                <?php endif; ?>
                            </a>
                        </h3>
                        <button class="tz-search pull-right"> <i class="fa fa-search"></i></button>
                        <nav class="pull-right tznav-menu">
                            <?php
                                if ( has_nav_menu('primary') ):
                                    wp_nav_menu(array(
                                       'theme_location' =>  'primary',
                                        'container'     =>  false,
                                        'menu_class'    =>  'tz-menu nav-collapse'
                                    ));
                                else:
                            ?>
                                    <ul class="tz-menu">
                                        <li>
                                            <a href="<?php echo get_admin_url().'/nav-menus.php'; ?>">
                                                ADD TO MENU
                                            </a>
                                        </li>
                                    </ul>
                            <?php
                                endif;
                            ?>
                        </nav>
                    </div>
                </div>
            <?php
                elseif( $header_option == 'header2' ):
            ?>
                <div class="container">
                    <div class="row">

                        <div class="col-md-5-custom">
                            <button data-target=".nav-collapse" class="btn-navbar tz_icon_menu" type="button">
                                <i class="fa fa-bars"></i>
                            </button>
                            <nav class="pull-right">
                                <?php
                                if ( has_nav_menu('primary-left') ):
                                    wp_nav_menu(array(
                                        'theme_location' =>  'primary-left',
                                        'container'     =>  false,
                                        'menu_class'    =>  'tz-menu nav-collapse'
                                    ));
                                else:
                                    ?>
                                    <ul class="tz-menu">
                                        <li>
                                            <a href="<?php echo get_admin_url().'/nav-menus.php'; ?>">
                                                ADD TO MENU
                                            </a>
                                        </li>
                                    </ul>
                                <?php
                                endif;
                                ?>

                            </nav>
                        </div>
                        <div class="col-md-2-custom">
                            <h3 class="tzlogo">
                                <a href="<?php echo get_home_url(); ?>" title="<?php bloginfo('name'); ?>">
                                    <?php if( isset( $logo ) && !empty( $logo ) ): ?>
                                        <img src="<?php echo esc_url(wp_get_attachment_url( $logo )); ?>" alt="<?php bloginfo('name'); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url(PLUGIN_PATH.'images/Everline_logo.png'); ?>" alt="<?php bloginfo('name'); ?>">
                                    <?php endif; ?>
                                </a>
                            </h3>
                        </div>
                        <div class="col-md-5-custom">
                            <nav class="pull-left">
                                <?php
                                if ( has_nav_menu('primary-right') ):
                                    wp_nav_menu(array(
                                        'theme_location' =>  'primary-right',
                                        'container'      =>  false,
                                        'menu_class'     =>  'tz-menu nav-collapse'
                                    ));
                                else:
                                    ?>
                                    <ul class="tz-menu">
                                        <li>
                                            <a href="<?php echo get_admin_url().'/nav-menus.php'; ?>">
                                                ADD TO MENU
                                            </a>
                                        </li>
                                    </ul>
                                <?php
                                endif;
                                ?>

                            </nav>
                            <button class="tz-search pull-left"> <i class="fa fa-search"></i></button>
                        </div>
                    </div>
                </div>
            <?php
                elseif( $header_option == 'header3' ):
            ?>
                <div class="container">
                    <h3 class="tzlogo">
                        <button data-target=".nav-collapse" class="btn-navbar tz_icon_menu" type="button">
                            <i class="fa fa-bars"></i>
                        </button>
                        <a href="<?php echo get_home_url(); ?>" title="<?php bloginfo('name'); ?>">
                            <?php if( isset( $logo ) && !empty( $logo ) ): ?>
                                <img src="<?php echo esc_url(wp_get_attachment_url( $logo )); ?>" alt="<?php bloginfo('name'); ?>">
                            <?php else: ?>
                                <img src="<?php echo esc_url(PLUGIN_PATH.'images/Everline_logo.png'); ?>" alt="<?php bloginfo('name'); ?>">
                            <?php endif; ?>
                        </a>
                        <button class="tz-search pull-left"> <i class="fa fa-search"></i></button>
                    </h3>
                </div>
                <nav class="tznav-3">
                    <div class="container">
                        <?php
                        if ( has_nav_menu('primary') ):
                            wp_nav_menu(array(
                                'theme_location' =>  'primary',
                                'container'     =>  false,
                                'menu_class'    =>  'tz-menu nav-collapse'
                            ));
                        else:
                            ?>
                            <ul class="tz-menu">
                                <li>
                                    <a href="<?php echo get_admin_url().'/nav-menus.php'; ?>">
                                        ADD TO MENU
                                    </a>
                                </li>
                            </ul>
                        <?php
                        endif;
                        ?>
                    </div>
                </nav>

            <?php
                elseif( $header_option == 'header4' ):
            ?>
                <?php if ( $title != '' && isset( $title )  ): ?>
                    <div class="content-top">
                        <div class="container">
                            <?php  echo esc_html($title) ;?>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="container">
                    <button data-target=".nav-collapse" class="btn-navbar tz_icon_menu" type="button">
                        <i class="fa fa-bars"></i>
                    </button>
                    <h3 class="tzlogo pull-left">
                        <a href="<?php echo get_home_url(); ?>" title="<?php bloginfo('name'); ?>">
                            <?php if( isset( $logo ) && !empty( $logo ) ): ?>
                                <img src="<?php echo esc_url(wp_get_attachment_url( $logo )); ?>" alt="<?php bloginfo('name'); ?>">
                            <?php else: ?>
                                <img src="<?php echo esc_url(PLUGIN_PATH.'images/Everline_logo.png'); ?>" alt="<?php bloginfo('name'); ?>">
                            <?php endif; ?>
                        </a>
                    </h3>
                    <button class="tz-search pull-right"> <i class="fa fa-search"></i></button>
                    <nav class="pull-right">
                        <?php
                        if ( has_nav_menu('primary') ):
                            wp_nav_menu(array(
                                'theme_location' =>  'primary',
                                'container'     =>  false,
                                'menu_class'    =>  'tz-menu nav-collapse'
                            ));
                        else:
                            ?>
                            <ul class="tz-menu">
                                <li>
                                    <a href="<?php echo get_admin_url().'/nav-menus.php'; ?>">
                                        ADD TO MENU
                                    </a>
                                </li>
                            </ul>
                        <?php
                        endif;
                        ?>
                    </nav>
                </div>
        <?php
            elseif( $header_option == 'header5' ):
        ?>
                <div class="wrapbox">
                    <div class="container">
                        <div class="nav_contro">
                            <h3 class="tzlogo pull-left">
                                <a href="<?php echo get_home_url(); ?>" title="<?php bloginfo('name'); ?>">
                                    <?php if( isset( $logo ) && !empty( $logo ) ): ?>
                                        <img src="<?php echo esc_url(wp_get_attachment_url( $logo )); ?>" alt="<?php bloginfo('name'); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url(PLUGIN_PATH.'images/Everline_logo.png'); ?>" alt="<?php bloginfo('name'); ?>">
                                    <?php endif; ?>
                                </a>
                            </h3>
                            <button class="tz-search pull-right"> <i class="fa fa-search"></i></button>
                            <button data-target=".nav-collapse" class="btn-navbar tz_icon_menu" type="button">
                                <i class="fa fa-bars"></i>
                            </button>
                            <nav class="pull-right">
                                <?php
                                if ( has_nav_menu('primary') ):
                                    wp_nav_menu(array(
                                        'theme_location' =>  'primary',
                                        'container'     =>  false,
                                        'menu_class'    =>  'tz-menu nav-collapse'
                                    ));
                                else:
                                    ?>
                                    <ul class="tz-menu">
                                        <li>
                                            <a href="<?php echo get_admin_url().'/nav-menus.php'; ?>">
                                                ADD TO MENU
                                            </a>
                                        </li>
                                    </ul>
                                <?php
                                endif;
                                ?>
                            </nav>
                        </div>
                    </div>
                </div>
        <?php
            endif;
        ?>
    </header>
    <div class="tzform-search">
        <img class="tzcontro_search" src="<?php echo esc_url(PLUGIN_PATH .'/assets/images/icon_search_delete.png') ; ?>" alt="icon search">
        <?php get_search_form(); ?>
    </div>
<?php
    $content_everline = ob_get_contents();
    ob_end_clean();
    return $content_everline;
}
add_shortcode('tzheader', 'tzdekor_header');
?>