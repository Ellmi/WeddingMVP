<?php
    // [testimonials]

    function tzdekor_testimonials( $atts ){

        extract( shortcode_atts( array(
            'defaultstyle'       =>  '',
            'style'       =>  '',
            'posts_per_page'      =>  ''
        ), $atts ) );
        ob_start() ;


        $class_box   = '';
        $class_style = '' ;
        if ( $defaultstyle == 'nodefault' ):
            $class_box = 'tzremovedefault';
        endif;

        if ( $style == 1 ):
            $class_style = 'testimonials2';
        endif;
    ?>
    <div class="tz-testimonials <?php echo esc_attr($class_box).' '.esc_attr($class_style); ?>">
        <div class="container">
            <ul class="tz-quote">
                <?php
                    $args  = array(
                        'post_type'         =>  'testimonials',
                        'posts_per_page'    =>  $posts_per_page
                    );
                    $quote = new WP_Query( $args );
                   if( $quote -> have_posts() ):
                       while( $quote -> have_posts() ):
                           $quote -> the_post();
                ?>
                            <li>
                                <i class="fa fa-heart-o icon_testimonials"></i>
                                <h3 class="title_testimonials">
                                    <i class="fa fa-quote-left"></i><?php the_title() ?><i class="fa fa-quote-right"></i>
                                </h3>
                                <span class="author_testimonials"><?php echo get_the_excerpt(); ?></span>
                            </li>
                <?php
                        endwhile;
                   endif;
                   wp_reset_postdata();
                ?>
            </ul>
        </div>
    </div>
    <?php
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
    }
    add_shortcode('testimonials', 'tzdekor_testimonials');
?>