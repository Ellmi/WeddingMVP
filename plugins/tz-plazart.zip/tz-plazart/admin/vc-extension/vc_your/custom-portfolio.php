<?php

    function tzplazart_vcportfolio( $atts ) {

        extract( shortcode_atts(array(
            'style'     =>  1,
            'column'    =>  3,
            'title'     =>  '',
            'cat'       =>  '',
            'limit'     =>  6
        ), $atts) );
        ob_start();
        wp_enqueue_script('jquery-isotope');
        wp_enqueue_script('custom-portfolio');
        if ( isset( $title ) && !empty( $title ) ):
            echo '<h3 class="tztitle">'.esc_html($title).'</h3>';
        endif;
        if ( isset( $cat ) && !empty( $cat ) ):
            $args   =   array(
                'post_type'         =>  'portfolio',
                'posts_per_page'    =>  $limit,
                'tax_query'         =>  array(
                    array(
                        'taxonomy'    =>  'portfolio-category',
                        'field'       =>  'id',
                        'terms'       =>  $cat
                    )
                )
            );
        else:
            $args   =   array(
                'post_type'         =>  'portfolio',
                'posts_per_page'    =>  $limit
            );
        endif;
        if ( $style == 1 ):
    ?>

            <div class="tz-portfolio-content" data-option-column="<?php echo esc_attr($column); ?>">
                <?php

                    $portfolio = new WP_Query( $args ) ;
                    if ( $portfolio -> have_posts() ):
                        while( $portfolio -> have_posts() ):
                            $portfolio -> the_post();

                ?>
                <div id="post-<?php the_ID() ?>" <?php post_class('element'); ?>>
                    <div class="portfolio-item portfolio-padding">
                        <div class="item-image">
                            <?php the_post_thumbnail('full'); ?>
                        </div>
                        <div class="tzitem-content">
                            <i class="fa fa-heart-o tzicon"></i>
                            <h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
                            <div class="tzmeta">
                                <span><?php echo get_the_date(); ?> /</span>
                            <span class="tztag">
                                <?php the_terms(get_the_ID(),'portfolio-tags','',',',''); ?>
                            </span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                        endwhile;
                    endif;
                    wp_reset_postdata();
                ?>
            </div>
    <?php else: ?>
            <div class="container">

                <div class="tz-portfolio-content  tzportfolio-style2" data-option-column="<?php echo esc_attr($column); ?>">
                    <?php
                    $portfolio = new WP_Query( $args ) ;
                    if ( $portfolio -> have_posts() ):
                        while( $portfolio -> have_posts() ):
                            $portfolio -> the_post();

                            ?>
                            <div id="post-<?php the_ID() ?>" <?php post_class('element portfolio-item2'); ?>>
                                <div class="portfolio-padding">
                                    <div class="item-image">
                                        <?php the_post_thumbnail('full'); ?>
                                    </div>
                                    <div class="tzitem-content">
                                        <i class="fa fa-heart-o tzicon"></i>
                                        <h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
                                        <div class="tzmeta">
                                            <span><?php echo get_the_date(); ?> /</span>
                                        <span class="tztag">
                                            <?php the_terms(get_the_ID(),'portfolio-tags','',',',''); ?>
                                        </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php
                        endwhile;
                    endif;
                    wp_reset_postdata();
                    ?>
                </div>

            </div>
    <?php endif; ?>
    <?php
        $everline_content = ob_get_contents();
        ob_end_clean();
        return $everline_content;
    }

    add_shortcode('tzportfolio', 'tzplazart_vcportfolio');

?>