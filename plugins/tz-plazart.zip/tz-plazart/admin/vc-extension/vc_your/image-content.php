<?php


    function tzplazart_image_content( $atts ){
         extract(shortcode_atts(array(
             'image'        =>  '',
             'icon'         =>  '',
             'description'  =>  ''
         ),$atts));
        ob_start();
    ?>
    <div class="tzimage-content" style="background-image: url('<?php echo esc_url(wp_get_attachment_url( $image)); ?>')">
        <div class="tzimg-content">
            <i class="fa <?php echo esc_attr($icon) ?> custom-icon"></i>
            <?php if ( isset( $description ) && $description != '' ): echo rawurldecode(base64_decode(strip_tags($description)));  endif; ?>
        </div>
    </div>
    <?php
        $everline_content = ob_get_contents();
        ob_end_clean();
        return $everline_content;
    }
    add_shortcode('image_content','tzplazart_image_content');
?>