<?php

    function tzplazart_ourstory( $atts ) {

        extract( shortcode_atts( array(
            'style'             =>  1,
            'title'             =>  '',
            'description'       =>  '',
            'image_left'        =>  '',
            'the_groom'         =>  '',
            'name_groom'        =>  '',
            'description_groom' =>  '',
            'the_bride'         =>  '',
            'name_bride'        =>  '',
            'description_bride' =>  ''
        ), $atts ) );
        ob_start();
        if ( $style == 1 ):
    ?>
        <div class="tzourstory">
            <div class="container">
                <?php if ( isset( $title ) && $title != '' ): ?>
                    <h3 class="title_ourstory"><?php echo esc_html($title); ?></h3>
                <?php endif; ?>
                <div class="ourstory_content">
                    <?php if ( isset( $description ) && $description != '' ): echo rawurldecode(base64_decode(strip_tags($description)));  endif; ?>
                </div>

            </div>
        </div>
    <?php elseif( $style == 2 ): ?>
        <div class="tzourstory2">
            <div class="container">
                <div class="row">
                    <div class="col-md-7 rtl-right">
                        <?php echo wp_get_attachment_image($image_left,'full','', array('class'=>'story_image pull-right')); ?>
                    </div>
                    <div class="col-md-5 rtl-left">
                        <?php if ( isset( $title ) && $title != '' ): ?>
                            <h3 class="title_ourstory"><?php echo esc_html($title); ?></h3>
                        <?php endif; ?>
                        <div class="ourstory_content">
                            <?php if ( isset( $description ) && $description != '' ): echo rawurldecode(base64_decode(strip_tags($description)));  endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php elseif( $style == 3 ): ?>
        <div class="tzourstory3">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <div class="ourstory_infomation ourstory_infomation3">
                            <div class="story_user">
                                <?php echo wp_get_attachment_image($the_groom,'full','', array('class'=>'story_user_img')); ?>
                            </div>
                            <h4><?php echo esc_html($name_groom); ?></h4>
                            <p><?php echo esc_html($description_groom); ?></p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <?php if ( isset( $title ) && $title != '' ): ?>
                            <h3 class="title_ourstory"><?php echo esc_html($title); ?></h3>
                        <?php endif; ?>
                        <div class="ourstory_content">
                            <?php if ( isset( $description ) && $description != '' ): echo rawurldecode(base64_decode(strip_tags($description)));  endif; ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="ourstory_infomation ourstory_infomation3">
                            <div class="story_user">
                                <?php echo wp_get_attachment_image($the_bride,'full','', array('class'=>'story_user_img')); ?>
                            </div>
                            <h4><?php echo esc_html($name_bride); ?></h4>
                            <p><?php echo esc_html($description_bride); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php elseif( $style == 4 ): ?>
        <div class="tzourstory4">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-7 rtl-right">
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <div class="ourstory_infomation">
                                    <div class="story_user">
                                        <?php echo wp_get_attachment_image($the_groom,'full','', array('class'=>'story_user_img')); ?>
                                    </div>
                                    <h4><?php echo esc_html($name_groom); ?></h4>
                                    <p><?php echo esc_html($description_groom); ?></p>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="ourstory_infomation">
                                    <div class="story_user">
                                        <?php echo wp_get_attachment_image($the_bride,'full','', array('class'=>'story_user_img')); ?>
                                    </div>
                                    <h4><?php echo esc_html($name_bride); ?></h4>
                                    <p><?php echo esc_html($description_bride); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7 col-sm-5 rtl-left">
                        <?php if ( isset( $title ) && $title != '' ): ?>
                            <h3 class="title_ourstory"><?php echo esc_html($title); ?></h3>
                        <?php endif; ?>
                        <div class="ourstory_content">
                            <?php if ( isset( $description ) && $description != '' ): echo rawurldecode(base64_decode(strip_tags($description)));  endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
        endif;
        $content_everline = ob_get_contents();
        ob_end_clean();
        return $content_everline;
    }
    add_shortcode('ourstory', 'tzplazart_ourstory');
?>