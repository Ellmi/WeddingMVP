<?php

    function tzeverline_contact( $atts ){
            extract(shortcode_atts(array(
                'phone'     =>      '',
                'address'   =>      '',
                'email'     =>      ''
            ),$atts));
        ob_start();
    ?>
        <div class="container">
            <div class="tzcontact-info">
                <div class="row">
                    <div class="col-md-4 col-sm-4">
                        <div class="tzphone">
                            <i class="fa fa-mobile-phone"></i>
                            <span><?php echo esc_html($phone); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="tzaddress">
                            <i class="fa fa-map-marker"></i>
                            <address><?php echo esc_html($address) ?></address>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="tzemail">
                            <i class="fa fa-envelope"></i>
                            <span><?php echo esc_html($email); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
        $tzcontact = ob_get_contents();
        ob_end_clean();
        return $tzcontact;
    }
    add_shortcode('contact_info','tzeverline_contact');
?>