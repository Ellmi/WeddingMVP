<?php

    function tzeverline_comingsoon($atts){
        extract(shortcode_atts(array(
            'title'          =>  '',
            'background_img' => '',
            'days'           =>  '',
            'date'           =>  '',
            'year'           =>  '',
            'time'           =>  ''
        ), $atts));
        ob_start();
        wp_enqueue_script('countdown');

    ?>

        <div class="tzcomingsoon" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($background_img)); ?>)">
            <div class="container">
                <h1 class="coming-title"><?php echo esc_html($title); ?></h1>
                <div class="row countdown">
                    <div class="col-md-3">
                        <div class="tzcountdownitem">
                            <span class="days">00</span>
                            <p class="timeRefDays"><?php echo _('days', TEXT_DOMAIN); ?></p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="tzcountdownitem">
                            <span class="hours">00</span>
                            <p class="timeRefHours"><?php echo _('hours', TEXT_DOMAIN); ?></p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="tzcountdownitem">
                            <span class="minutes">00</span>
                            <p class="timeRefMinutes"><?php echo _('minutes', TEXT_DOMAIN); ?></p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="tzcountdownitem">
                            <span class="seconds">00</span>
                            <p class="timeRefSeconds"><?php echo _e('seconds', TEXT_DOMAIN) ?></p>
                        </div>
                    </div>
                </div>
                <p class="comingsoo_ds">
                    <?php echo __('Comeback to',TEXT_DOMAIN); ?> <a href="<?php site_url(); ?>"><?php echo _e('homepage',TEXT_DOMAIN); ?></a>
                </p>
            </div>
        </div>
        <script>
            jQuery(document).ready(function(){
                jQuery(".countdown").countdown({
                    date: "<?php echo $days.' '.$date.' '.$year.' '.$time; ?>", // add the countdown's end date (i.e. 3 november 2012 12:00:00)
                    format: "on" // on (03:07:52) | off (3:7:52) - two_digits set to ON maintains layout consistency
                });
            });
        </script>
    <?php
        $tzcoming = ob_get_contents();
        ob_end_clean();
        return $tzcoming;
    }
    add_shortcode('comingsoon','tzeverline_comingsoon');
?>