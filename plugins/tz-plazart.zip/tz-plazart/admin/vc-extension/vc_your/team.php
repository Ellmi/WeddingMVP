<?php
    function tzeverline_team( $atts ){
        extract(shortcode_atts(array(
            'title'     =>  '',
            'limit'     =>  5,
            'category'  =>  ''
        ), $atts));
        ob_start();

            if ( isset($category) && $category != '' ):
    ?>
            <div class="tzteam">
                <div class="container">
                    <?php if ( isset( $title ) && !empty($title) ): ?><h3 class="team_title"><?php echo esc_html($title); ?></h3><?php endif; ?>
                    <div class="row">
                        <?php
                            $team_args = array(
                                'post_type'         =>  'ourteam',
                                'posts_per_page'    =>  $limit,
                                'tax_query'         =>  array(
                                    array(
                                        'taxonomy'  =>  'ourteam-category',
                                        'field'     =>  'id',
                                        'terms'     =>  $category
                                    )
                                )
                            );
                            $team_query = new WP_Query( $team_args );

                            if ( $team_query -> have_posts() ):
                                while( $team_query -> have_posts() ):
                                    $team_query -> the_post();
                                    $name     = get_post_meta( get_the_ID(), THEME_PREFIX.'_team_name', true );
                                    $position = get_post_meta( get_the_ID(), THEME_PREFIX.'_team_Position', true );
                                    $link     = get_post_meta( get_the_ID(), THEME_PREFIX.'_team_link', true );
                        ?>

                            <div class="col-md-3 col-sm-6">
                               <div class="tzteam-item">
                                   <div class="tzteam-img">
                                       <?php the_post_thumbnail('full'); ?>
                                       <?php if ( isset( $link ) && !empty( $link ) ): ?>
                                           <a class="team_readmore" href="<?php echo esc_url($link) ?>"><i class="fa fa-link"></i></a>
                                        <?php endif; ?>
                                   </div>
                                   <div class="tzteam-meta">
                                       <h4>
                                           <?php
                                                if ( isset( $name ) && !empty( $name ) ):
                                                    echo esc_html($name);
                                                else:
                                                    the_title();
                                                endif;
                                           ?>
                                       </h4>
                                       <?php if ( isset( $position ) && !empty($position) ): ?>
                                            <span><?php echo esc_html($position); ?></span>
                                        <?php endif; ?>
                                   </div>
                               </div>
                            </div>

                        <?php
                                endwhile;
                            endif;
                        wp_reset_postdata();
                        ?>
                    </div>
                </div>
            </div>
    <?php
            endif;
        $tzever = ob_get_contents();
        ob_end_clean();
        return $tzever;
    }
    add_shortcode('team','tzeverline_team');
?>