<?php

    function tzplazart_blog( $atts ) {
        extract(shortcode_atts(array(
            'title'     =>  '',
            'columns'   =>  'col-md-3',
            'type'      =>  1,
            'style'     =>  1,
            'cat'       =>  '',
            'limit'     =>  4
        ), $atts));
        ob_start();
        if ( $type == 1 ):
            $args = array(
                'post_type'         =>  'post',
                'posts_per_page'    =>  $limit
            );
        else:
            $args = array(
                'post_type'         =>  'post',
                'posts_per_page'    =>  $limit,
                'cat'               =>  $cat
            );
        endif;
        $blog_class = '';
        if ( $style == 2 ){
            $blog_class = 'blog-style2';
        }
        $title_class  =  '';
        if ( $columns == 'col-md-3' ):
            $title_class = 'elementblog-title2';
            $columns = 'col-md-3 col-sm-6';
        endif;
        if ( $columns == 'col-md-12' ):
            $title_class = 'elementblog-title3';
        endif;
    ?>
    <div class="container-custom">
        <?php if( isset( $title ) && !empty( $title ) ): ?>
            <h2 class="elementblog-title <?php echo esc_attr($title_class); ?>"><?php echo esc_html($title); ?></h2>
        <?php endif; ?>
        <div class="row">
            <?php
            $blog = new WP_Query( $args );
            if ( $blog -> have_posts() ):
                while( $blog -> have_posts() ):
                    $blog -> the_post();
            ?>
                    <div class="<?php echo esc_attr($columns); ?>">
                        <div class="blog-item <?php echo esc_attr($blog_class); ?>">
                            <div class="blog-image">
                                <?php the_post_thumbnail('medium'); ?>
                            </div>
                            <div class="blog-description">
                                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <span class="tzblog_meta">
                                <?php echo get_the_date(); ?>
                                /
                                <?php
                                if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ):
                                    comments_popup_link(__('Leave a comment', TEXT_DOMAIN), __('1 Comment', TEXT_DOMAIN), __(' % Comment(s) ', TEXT_DOMAIN) );
                                endif;
                                ?>
                            </span>
                                <?php the_excerpt(); ?>
                                <a class="tzblog_readmore" href="<?php the_permalink(); ?>"><?php echo _e('READ MORE', TEXT_DOMAIN); ?></a>
                            </div>
                        </div>
                    </div>
                <?php
                endwhile;
            endif;
            wp_reset_postdata();
            ?>
        </div>
    </div>

    <?php
        $everline_content = ob_get_contents();
        ob_end_clean();
        return $everline_content;
    }

    add_shortcode('tzblog', 'tzplazart_blog');

?>