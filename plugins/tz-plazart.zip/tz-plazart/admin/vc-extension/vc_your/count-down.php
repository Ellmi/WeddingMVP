<?php
    function tzeverline_count_down( $atts ) {

        extract(shortcode_atts(array(
            'style'          =>  1,
            'title'          =>  '',
            'icon'           =>  '',
            'description'    =>  '',
            'background_img' => '',
            'days'           =>  '',
            'date'           =>  '',
            'year'           =>  '',
            'time'           =>  ''
        ), $atts));
        ob_start();
        wp_enqueue_script('countdown');
    ?>
    <?php if ( $style == 1 ): ?>
        <div class="tzcountdown">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 rtl-right">
                        <div class="tzcountdown-left">
                            <?php if ( isset( $icon ) && $icon != '' ): ?>
                                <i class="<?php echo esc_attr($icon); ?> tzcountdown-icon"></i>
                            <?php endif; ?>
                            <div class="tzcountdown-ds">
                                <?php if ( isset( $description ) && $description != '' ): echo rawurldecode(base64_decode(strip_tags($description)));  endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8 rtl-left">
                        <div class="row countdown">
                            <div class="col-md-3">
                                <div class="tzcountdownitem">
                                    <span class="days">00</span>
                                    <p class="timeRefDays"><?php echo _e('days', TEXT_DOMAIN); ?></p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="tzcountdownitem">
                                    <span class="hours">00</span>
                                    <p class="timeRefHours"><?php echo _e('hours', TEXT_DOMAIN); ?></p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="tzcountdownitem">
                                    <span class="minutes">00</span>
                                    <p class="timeRefMinutes"><?php echo _e('minutes', TEXT_DOMAIN); ?></p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="tzcountdownitem">
                                    <span class="seconds">00</span>
                                    <p class="timeRefSeconds"><?php echo _e('seconds', TEXT_DOMAIN); ?></p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    <?php elseif( $style == 2 ): ?>
        <div class="tzcountdown2">
            <div class="container">
                <?php if ( isset( $title ) && $title != '' ): ?>
                    <h3 class="tzcount_title"><?php echo esc_html($title); ?></h3>
                <?php endif; ?>
                <div class="countdown">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="tzcountdownitem">
                                <span class="days">00</span>
                            </div>
                            <p class="timeRefDays tzcount-ds"><?php echo _e('days', TEXT_DOMAIN); ?></p>
                        </div>
                        <div class="col-md-3">
                            <div class="tzcountdownitem">
                                <span class="hours">00</span>
                            </div>
                            <p class="timeRefHours tzcount-ds"><?php echo _('hours', TEXT_DOMAIN); ?></p>
                        </div>
                        <div class="col-md-3">
                            <div class="tzcountdownitem">
                                <span class="minutes tzcount-ds">00</span>
                            </div>
                            <p class="timeRefMinutes tzcount-ds"><?php echo _e('minutes', TEXT_DOMAIN); ?></p>
                        </div>
                        <div class="col-md-3">
                            <div class="tzcountdownitem">
                                <span class="seconds">00</span>
                            </div>
                            <p class="timeRefSeconds tzcount-ds"><?php echo _e('seconds', TEXT_DOMAIN); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php elseif( $style == 3 ): ?>
        <div class="tzcountdown3">
            <div class="tzcount-left" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($background_img)); ?>)">
                <i class="fa fa-heart-o tzcountdown-icon2"></i>
                <div class="tzcountdown-ds2">
                    <?php if ( isset( $description ) && $description != '' ): echo rawurldecode(base64_decode(strip_tags($description)));  endif; ?>
                </div>
            </div>
            <div class="tzcount-right countdown">
                <div class="tzdown3-item">
                    <div class="tzcountdownitem">
                        <span class="days">00</span>
                    </div>
                    <p class="timeRefDays tzcount-ds"><?php echo _e('days', TEXT_DOMAIN); ?></p>
                </div>
                <div class="tzdown3-item">
                    <div class="tzcountdownitem">
                        <span class="hours">00</span>
                    </div>
                    <p class="timeRefHours tzcount-ds"><?php echo _e('hours', TEXT_DOMAIN); ?></p>
                </div>
                <div class="tzdown3-item">
                    <div class="tzcountdownitem">
                        <span class="minutes tzcount-ds">00</span>
                    </div>
                    <p class="timeRefMinutes tzcount-ds"><?php echo _e('minutes', TEXT_DOMAIN); ?></p>
                </div>
                <div class="tzdown3-item">
                    <div class="tzcountdownitem">
                        <span class="seconds">00</span>
                    </div>
                    <p class="timeRefSeconds tzcount-ds"><?php echo _('seconds', TEXT_DOMAIN); ?></p>
                </div>
            </div>
        </div>
    <?php elseif( $style == 4 ): ?>
             <div class="tzcountdown4">
                 <div class="container">
                     <h3 class="tzcount_title2">
                         <?php if ( isset( $icon ) && $icon != '' ): ?>
                             <i class="<?php echo esc_attr($icon); ?>"></i>
                         <?php endif; ?>
                         <?php if ( isset( $title ) && $title != '' ): echo esc_html($title);  endif; ?>
                     </h3>
                     <div class="countdown">
                         <div class="row">
                             <div class="col-md-3">
                                 <div class="tzcountdownitem">
                                     <span class="days">00</span>
                                     <p class="timeRefDays"><?php echo _e('days',TEXT_DOMAIN); ?></p>
                                 </div>
                             </div>
                             <div class="col-md-3">
                                 <div class="tzcountdownitem">
                                     <span class="hours">00</span>
                                     <p class="timeRefHours"><?php echo _e('hours', TEXT_DOMAIN); ?></p>
                                 </div>
                             </div>
                             <div class="col-md-3">
                                 <div class="tzcountdownitem">
                                     <span class="minutes">00</span>
                                     <p class="timeRefMinutes"><?php echo _e('minutes', TEXT_DOMAIN); ?></p>
                                 </div>
                             </div>
                             <div class="col-md-3">
                                 <div class="tzcountdownitem">
                                     <span class="seconds">00</span>
                                     <p class="timeRefSeconds">seconds</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
    <?php endif; ?>

        <script>
            jQuery(document).ready(function(){
                jQuery(".countdown").countdown({
                    date: "<?php echo $days.' '.$date.' '.$year.' '.$time; ?>", // add the countdown's end date (i.e. 3 november 2012 12:00:00)
                    format: "on" // on (03:07:52) | off (3:7:52) - two_digits set to ON maintains layout consistency
                });
            });
        </script>
        <?php $content_everline = ob_get_contents();
        ob_end_clean();
        return $content_everline;

    }
    add_shortcode('countdown','tzeverline_count_down');

?>