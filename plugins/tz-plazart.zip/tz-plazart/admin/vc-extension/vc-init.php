<?php

/*=====================================
 * Visual Composer
 =====================================*/



if ( class_exists('WPBakeryVisualComposerAbstract') ):
    function tzplazart_includevisual(){
        $dir_vc = dirname( __FILE__ );

        require_once $dir_vc . '/visual-composer/custom_vc.php';
        // VC Templates
        $vc_templates_dir = $dir_vc . '/visual-composer/vc_templates/';
        vc_set_shortcodes_templates_dir($vc_templates_dir);

        require_once $dir_vc . '/vc_your/your-header.php';
        require_once $dir_vc . '/visual-composer/vc-your-header.php';
        require_once $dir_vc . '/vc_your/count-down.php';
        require_once $dir_vc . '/visual-composer/vc-count-down.php';
        require_once $dir_vc . '/vc_your/our-story.php';
        require_once $dir_vc . '/visual-composer/vc-our-story.php';
        require_once $dir_vc . '/vc_your/introduct.php';
        require_once $dir_vc . '/visual-composer/vc-introduct.php';
        require_once $dir_vc . '/vc_your/custom-portfolio.php';
        require_once $dir_vc . '/visual-composer/vc-custom-portfolio.php';
        require_once $dir_vc . '/vc_your/video.php';
        require_once $dir_vc . '/visual-composer/vc-video.php';
        require_once $dir_vc . '/vc_your/blog.php';
        require_once $dir_vc . '/visual-composer/vc-blog.php';
        require_once $dir_vc . '/vc_your/playlist.php';
        require_once $dir_vc . '/visual-composer/vc-playlist.php';
        require_once $dir_vc . '/vc_your/testimonials.php';
        require_once $dir_vc . '/visual-composer/vc-testimonials.php';
        require_once $dir_vc . '/vc_your/image-content.php';
        require_once $dir_vc . '/visual-composer/vc-image-content.php';
        require_once $dir_vc . '/vc_your/title.php';
        require_once $dir_vc . '/visual-composer/vc-title.php';
        require_once $dir_vc . '/vc_your/team.php';
        require_once $dir_vc . '/visual-composer/vc_team.php';
        require_once $dir_vc . '/vc_your/contact-info.php';
        require_once $dir_vc . '/visual-composer/vc-contact-info.php';
        require_once $dir_vc . '/vc_your/comingsoon.php';
        require_once $dir_vc . '/visual-composer/vc-comingsoon.php';

    }

    add_action('init', 'tzplazart_includevisual', 20);
endif;

?>
