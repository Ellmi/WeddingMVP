<?php
    $team = array();
    $category = get_categories(array(
        'taxonomy'  =>  'ourteam-category'
    ));
    if ( isset( $category ) && !empty( $category ) ):
        foreach( $category as $cate ):
            $team[$cate -> name]    =   $cate->term_id ;
        endforeach;
    endif;
    vc_map( array(
        'base'      =>  'team',
        'name'      =>  'Team Members',
        'icon'      =>  'tzvc_icon',
        'category'  =>  'Everline Theme',
        'params'    =>  array(
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Title',
                'param_name'    =>  'title',
                'value'         =>  ''
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Limit',
                'param_name'    =>  'limit',
                'value'         =>  ''
            ),
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Choose category',
                'param_name'    =>  'category',
                'value'         =>  $team
            )
        )
    ) )

?>