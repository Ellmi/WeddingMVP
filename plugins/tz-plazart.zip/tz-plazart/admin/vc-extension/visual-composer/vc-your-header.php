<?php
    vc_map( array(
        'name'      =>  'Header Option',
        'base'      =>  'tzheader',
        'icon'      =>  'tzvc_icon',
        'category'  =>  'Everline Theme',
        'params'    =>  array(
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'heading'       =>  'Choose type header',
                'admin_label'   =>  true,
                'param_name'    =>  'header_option',
                'value'         =>  array(
                    'Header style 1'    =>  'header1',
                    'Header style 2'    =>  'header2',
                    'Header style 3'    =>  'header3',
                    'Header style 4'    =>  'header4',
                    'Header style 5'    =>  'header5'
                )
            ),
            array(
                'type'          =>  'attach_image',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Upload Logo',
                'param_name'    =>  'logo',
                'value'         =>  ''
            ),
            array(
              'type'          =>  'textfield',
              'holder'        =>  'div',
              'admin_label'   =>  true,
              'heading'       =>  'Text title',
              'param_name'    =>  'title',
              'value'         =>  '',
              "dependency"    => Array('element' => "header_option", 'value' => array('header4'))
           )
        )
    ) );
?>