<?php

        vc_map( array(
            'base'      =>  'image_content',
            'name'      =>  'Image Content',
            'icon'      =>  'tzvc_icon',
            'category'  =>  'Everline Theme',
            'params'    =>  array(
                array(
                    'type'          =>  'attach_image',
                    'holder'        =>  'div',
                    'admin_label'   =>  true,
                    'heading'       =>  'Upload image',
                    'param_name'    =>  'image',
                    'value'         =>  ''
                ),
                array(
                    'type'          =>  'textfield',
                    'holder'        =>  'div',
                    'admin_label'   =>  true,
                    'description'   =>  "Element collection support font awesome, you can click <a href='http://fortawesome.github.io/Font-Awesome/icons/' target='_blank'>Click</a>",
                    'heading'       =>  'Import class icon',
                    'param_name'    =>  'icon',
                    'value'         =>  'fa fa-heart-o'
                ),
                array(
                    'type'          =>  'textarea_raw_html',
                    'holder'        =>  'div',
                    'admin_label'   =>  false,
                    'heading'       =>  'Content',
                    'param_name'    =>  'description',
                    "value"         => base64_encode( 'LOVE ME LIKE A <strong> LOVE SONG </strong> WEDDING LOVE SONGS LIST' ),
                    'description'   =>  "use  &#60;strong&#62text&#60;/strong&#62 tag to emphasize on your content",
                )
            )
        ) )

?>