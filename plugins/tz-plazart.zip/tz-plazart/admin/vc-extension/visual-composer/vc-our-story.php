<?php

    vc_map( array(
        'name'          =>  'Our Story',
        'base'          =>  'ourstory',
        'icon'          =>  'tzvc_icon',
        'description'   =>  'Our Story',
        'category'      =>  'Everline Theme',
        'params'        =>  array(
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Choose Style',
                'param_name'    =>  'style',
                'value'         =>  array(
                    'Style 1'   =>  1,
                    'Style 2'   =>  2,
                    'Style 3'   =>  3,
                    'Style 4'   =>  4
                )
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Title',
                'param_name'    =>  'title'
            ),
            array(
                'type'          =>  'textarea_raw_html',
                'holder'        =>  'div',
                'admin_label'   =>  false,
                'heading'       =>  'Content',
                'param_name'    =>  'description',
                "value"         => base64_encode( '<p>I am raw html block.<br/>Click edit button to change this html</p>' ),
            ),
            array(
                'type'          =>  'attach_image',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'The groom',
                'param_name'    =>  'the_groom',
                'value'         =>  '',
                "dependency"    => Array('element' => "style", 'value' => array('3','4'))
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Name Groom',
                'param_name'    =>  'name_groom',
                "dependency"    => Array('element' => "style", 'value' => array('3','4'))
            ),
            array(
                "type"          =>  "textarea",
                "holder"        =>  "div",
                "class"         =>  "",
                "heading"       =>  "Description groom",
                "param_name"    =>  "description_groom",
                "dependency"    => Array('element' => "style", 'value' => array('3','4')),
                "value"         =>  "",
            ),
            array(
                'type'          =>  'attach_image',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'The Bride',
                'param_name'    =>  'the_bride',
                'value'         =>  '',
                "dependency"    => Array('element' => "style", 'value' => array('3','4'))
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Name bride',
                'param_name'    =>  'name_bride',
                "dependency"    => Array('element' => "style", 'value' => array('3','4'))
            ),
            array(
                "type"          =>  "textarea",
                "holder"        =>  "div",
                "class"         =>  "",
                "heading"       =>  "Description bride",
                "param_name"    =>  "description_bride",
                "dependency"    => Array('element' => "style", 'value' => array('3','4')),
                "value"         =>  "",
            ),
            array(
                'type'          =>  'attach_image',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Image left',
                'param_name'    =>  'image_left',
                'value'         =>  '',
                "dependency"    => Array('element' => "style", 'value' => array('2'))
            )
        )
    ) );
?>