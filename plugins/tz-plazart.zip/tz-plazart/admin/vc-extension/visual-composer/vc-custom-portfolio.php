<?php
    $cat = array();
    $portfolio_cat = get_categories(array(
        'taxonomy'  =>  'portfolio-category'
    ));
    if ( isset( $portfolio_cat ) && !empty( $portfolio_cat ) ):
        foreach( $portfolio_cat as $cate ):
            $cat[ $cate -> name ] = $cate -> term_id;
        endforeach;
    endif;
    vc_map( array(
        'name'      =>  'Portfolios',
        'base'      =>  'tzportfolio',
        'icon'      =>  'tzvc_icon',
        'category'  =>  'Everline Theme',
        'params'    =>  array(
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Choose Style',
                'param_name'    =>  'style',
                'value'         =>  array(
                    'Full width'   =>  1,
                    'Boxed'        =>  2
                )
            ),
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Choose Column',
                'param_name'    =>  'column',
                'value'         =>  array(
                    '2 Columns'     => 2,
                    '3 Columns'     => 3,
                    '4 Columns'     => 4,
                    '5 Columns'     => 5,
                )
            ),
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Choose portfolio categories',
                'param_name'    =>  'cat',
                'value'         =>  $cat
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Title Portfolio',
                'param_name'    =>  'title',
                'value'         =>  'TITLE PORTFOLIO'
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Limit post',
                'param_name'    =>  'limit',
                'value'         =>  6
            )
        )
    ) )

?>