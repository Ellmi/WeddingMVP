<?php
    $count_day    = array(
        'January'     =>  'january',
        'February'    =>  'february',
        'March'       =>  'march',
        'April'       =>  'april',
        'May'         =>  'may',
        'June'        =>  'june',
        'July'        =>  'july',
        'August'      =>  'august',
        'September'   =>  'september',
        'October'     =>  'october',
        'November'    =>  'november',
        'December'    =>  'december'
    );

    $count_date    = array(
        '1'     =>  '1',
        '2'     =>  '2',
        '3'     =>  '3',
        '4'     =>  '4',
        '5'     =>  '5',
        '6'     =>  '6',
        '7'     =>  '7',
        '8'     =>  '8',
        '9'     =>  '9',
        '10'    =>  '10',
        '11'    =>  '11',
        '12'    =>  '12',
          '13'  =>  '13',
        '14'    =>  '14',
        '15'    =>  '15',
        '16'    =>  '16',
        '17'    =>  '17',
        '18'    =>  '18',
        '19'    =>  '19',
        '20'    =>  '20',
        '21'    =>  '21',
        '22'    =>  '22',
        '23'    =>  '23',
        '24'    =>  '24',
        '25'    =>  '25',
        '26'    =>  '26',
        '27'    =>  '27',
        '28'    =>  '28',
        '29'    =>  '29',
        '30'    =>  '30',
        '31'    =>  '31'
    );
    vc_map(array(
        'name'          =>  'Count Down',
        'base'          =>  'countdown',
        'icon'          =>  'tzvc_icon',
        'description'   =>  'output countdown',
        'category'      =>  'Everline Theme',
        'params'        =>  array(
            array(
              'type'            =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Count Down Style',
                'param_name'    =>  'style',
                'value'         =>  array(
                    'Style 1'   =>  1,
                    'Style 2'   =>  2,
                    'Style 3'   =>  3,
                    'Style 4'   =>  4,
                )
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'description'   =>  "Element collection support font awesome, you can click <a href='http://fortawesome.github.io/Font-Awesome/icons/' target='_blank'>Click</a>",
                'heading'       =>  'Import class icon',
                'param_name'    =>  'icon',
                'value'         =>  'fa fa-heart-o',
                "dependency"    => Array('element' => "style", 'value' => array('1','4'))
            ),
            array(
                "type"          => "textarea_raw_html",
                "holder"        => "div",
                "class"         => "",
                'admin_label'   =>  false,
                "heading"       => 'Description',
                "param_name"    => "description",
                "value"         => base64_encode( 'COUNTDOWN TO<br/><span>MICHAEL&JOHNNY</span><br>WEDDING CEREMONY' ),
                "description"   => "use &#60;br&#62 tag to break lines and &#60;span&#62text&#60;/span&#62 tag to emphasize on your content",
                "dependency"    => Array('element' => "style", 'value' => array('1','3'))
            ),
            array(
                'type'          =>  'attach_image',
                'holder'        =>  'div',
                'class'         =>  '',
                'admin_label'   =>  true,
                'heading'       =>  'Background Image',
                'param_name'    =>  'background_img',
                "dependency"    => Array('element' => "style", 'value' => array('3'))
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'description'   =>  "",
                'heading'       =>  'Title',
                'param_name'    =>  'title',
                'value'         =>  'Import TITLE',
                "dependency"    => Array('element' => "style", 'value' => array('2','4'))
            ),
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'description'   =>  "",
                'heading'       =>  'Date',
                'param_name'    =>  'date',
                'value'         =>  $count_date
            ),
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'description'   =>  "",
                'heading'       =>  'Days',
                'param_name'    =>  'days',
                'value'         =>  $count_day
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'description'   =>  "import year by number eg: 2016",
                'heading'       =>  'Year',
                'param_name'    =>  'year',
                'value'         =>  '2016'
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'description'   =>  "import year by number eg: 23:23:23",
                'heading'       =>  'Time',
                'param_name'    =>  'time',
                'value'         =>  '23:23:23'
            ),
        )
    ));
?>