<?php

    $cat = array();
    $categories = get_categories();
    if ( isset( $categories ) && !empty( $categories ) ):
        foreach( $categories as $cate ):
            $cat[ $cate->name ] = $cate -> term_id;
        endforeach;
    endif;
    vc_map( array(
        'base'          =>      'tzblog',
        'name'          =>      'Blog',
        'icon'          =>      'tzvc_icon',
        'category'      =>      'Everline Theme',
        'description'   =>      'Blog Content',
        'params'        =>      array(
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Title',
                'param_name'    =>  'title',
                'value'         =>  ''
            ),
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Choose Columns',
                'param_name'    =>  'columns',
                'value'         =>  array(
                    '4 Columns'     =>  'col-md-3',
                    '3 Columns'     =>  'col-md-4',
                    '2 Columns'     =>  'col-md-6',
                    '1 Columns'     =>  'col-md-12'
                )
            ),
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Choose Style',
                'param_name'    =>  'style',
                'value'         =>  array(
                    'Style 1'       =>  1,
                    'Style 2'       =>  2
                )
            ),
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'param_name'    =>  'type',
                'heading'       =>  'Display Blog by',
                'value'         =>  array(
                    'News post'     =>  1,
                    'By Category'   =>  2
                )
            ),
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Choose category',
                'param_name'    =>  'cat',
                'value'         =>  $cat,
                'dependency'    =>  Array(  'element' => 'type', 'value' => '2' )
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Limit Post',
                'param_name'    =>  'limit',
                'value'         =>  ''
            )

        )
    ) )

?>