<?php

    vc_map( array(
        'name'      =>  'Video HTML5',
        'base'      =>  'everline_video',
        'icon'      =>  'tzvc_icon',
        'category'  =>  'Everline Theme',
        'params'    =>  array(
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'heading'       =>  'Title',
                'admin_label'   =>  true,
                'param_name'    =>  'title',
                'value'         =>  'title'
            ),
            array(
                'type'          =>  'textarea',
                'holder'        =>  'div',
                'heading'       =>  'Description',
                'admin_label'   =>  true,
                'param_name'    =>  'description',
                'value'         =>  'Description'
            ),
            array(
                'type'          =>  'attach_image',
                'holder'        =>  'div',
                'heading'       =>  'Background image',
                'admin_label'   =>  true,
                'param_name'    =>  'image_background'
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'heading'       =>  'Video mp4 url eg: .mp4',
                'admin_label'   =>  true,
                'param_name'    =>  'video_mp4'
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'heading'       =>  'Video ogv url eg: .ogv ',
                'admin_label'   =>  true,
                'param_name'    =>  'video_ogg'
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'heading'       =>  'Video web url eg: .webm',
                'admin_label'   =>  true,
                'param_name'    =>  'video_web'
            )
        )
    ) ) ;

?>