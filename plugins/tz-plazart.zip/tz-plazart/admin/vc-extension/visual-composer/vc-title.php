<?php

    vc_map( array(
        'base'  =>  'tztitle',
        'name'  =>  'Title',
        'icon'  =>  'tzvc_icon',
        'description'   =>  'Your title',
        'params'        =>  array(
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Import text',
                'param_name'    =>  'title'
            )
        )
    ) );
?>