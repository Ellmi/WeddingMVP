<?php

    vc_map( array(
        'name'          =>  'Introduce',
        'base'          =>  'introduct',
        'icon'          =>  'tzvc_icon',
        'description'   =>  'Introduce content',
        'category'      =>  'Everline Theme',
        'params'        =>  array(
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Title',
                'param_name'    =>  'title',
                'value'         =>  ''
            ),
            array(
                'type'          =>  'attach_image',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Upload image',
                'param_name'    =>  'image',
                'value'         =>  ''
            ),
            array(
                'type'          =>  'textarea',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Content',
                'param_name'    =>  'description',
                'value'         =>  ''
            )
        )
    ) );

?>