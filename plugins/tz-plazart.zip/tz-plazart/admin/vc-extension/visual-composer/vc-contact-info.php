<?php

    vc_map( array(
        'base'      =>  'contact_info',
        'name'      =>  'Contact info',
        'icon'      =>  'tzvc_icon',
        'category'  =>  'Everline Theme',
        'params'    =>  array(
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Phone',
                'param_name'    =>  'phone',
                'value'         =>  ''
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Email',
                'param_name'    =>  'email',
                'value'         =>  ''
            ),
            array(
                'type'          =>  'textarea',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Address',
                'param_name'    =>  'address',
                'value'         =>  ''
            )

        )
    ) )

?>