<?php
    // [testimonials]

    vc_map( array(
        'name'      =>  'Testimonials',
        'base'      =>  'testimonials',
        'icon'      =>  'tzvc_icon',
        'category' =>  'Everline Theme',
        'params'    =>  array(
            array(
                "type"          =>  "dropdown",
                "holder"        =>  "div",
                "class"         =>  "",
                "heading"       =>  'Setup style',
                "param_name"    =>  "defaultstyle",
                'admin_label'   =>  true,
                "value"         =>  array(
                    "default style"    =>  "default",
                    "remove default"   =>  "nodefault",
                )
            ),
            array(
                "type"          =>  "dropdown",
                "holder"        =>  "div",
                "class"         =>  "",
                "heading"       =>  'Choose Style',
                "param_name"    =>  "style",
                'admin_label'   =>  true,
                "value"         =>  array(
                    "Style default"    =>  0,
                    "Style Color"      =>  1,
                )
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'heading'       =>  'Limit testimonials',
                'param_name'    =>  'posts_per_page',
                'admin_label'   =>  true,
                'value'         =>  10
            )
        )
    ) );

?>