<?php

    vc_map( array(
        'base'          =>  'tzplaylist',
        'name'          =>  'Playlist',
        'category'      =>  'Everline Theme',
        'description'   =>  'View Playlist',
        'icon'          =>  'tzvc_icon',
        'params'        =>  array(
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Title',
                'param_name'    =>  'title',
                'value'         =>  ''
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Limit Music',
                'param_name'    =>  'limit',
                'value'         =>  6
            ),
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'heading'       =>  'Autoplay Music ?',
                'param_name'    =>  'autoplay',
                'value'         =>  array(
                    'Yes'       =>  1,
                    'No'        =>  0
                )
            )
        )
    ) )

?>