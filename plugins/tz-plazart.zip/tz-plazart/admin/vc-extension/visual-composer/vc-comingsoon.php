<?php
    $count_day    = array(
        'January'     =>  'january',
        'February'    =>  'february',
        'March'       =>  'march',
        'April'       =>  'april',
        'May'         =>  'may',
        'June'        =>  'june',
        'July'        =>  'july',
        'August'      =>  'august',
        'September'   =>  'september',
        'October'     =>  'october',
        'November'    =>  'november',
        'December'    =>  'december'
    );

    $count_date    = array(
        '1'     =>  '1',
        '2'     =>  '2',
        '3'     =>  '3',
        '4'     =>  '4',
        '5'     =>  '5',
        '6'     =>  '6',
        '7'     =>  '7',
        '8'     =>  '8',
        '9'     =>  '9',
        '10'    =>  '10',
        '11'    =>  '11',
        '12'    =>  '12',
        '13'  =>  '13',
        '14'    =>  '14',
        '15'    =>  '15',
        '16'    =>  '16',
        '17'    =>  '17',
        '18'    =>  '18',
        '19'    =>  '19',
        '20'    =>  '20',
        '21'    =>  '21',
        '22'    =>  '22',
        '23'    =>  '23',
        '24'    =>  '24',
        '25'    =>  '25',
        '26'    =>  '26',
        '27'    =>  '27',
        '28'    =>  '28',
        '29'    =>  '29',
        '30'    =>  '30',
        '31'    =>  '31'
    );
    vc_map(array(
        'base'      =>  'comingsoon',
        'name'      =>  'Coming soon',
        'icon'      =>  'tzvc_icon',
        'category'  =>  'Everline Theme',
        'params'    =>  array(
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'description'   =>  "",
                'heading'       =>  'Title',
                'param_name'    =>  'title',
                'value'         =>  ''
            ),
            array(
                'type'          =>  'attach_image',
                'holder'        =>  'div',
                'class'         =>  '',
                'admin_label'   =>  true,
                'heading'       =>  'Background Image',
                'param_name'    =>  'background_img',
            ),
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'description'   =>  "",
                'heading'       =>  'Date',
                'param_name'    =>  'date',
                'value'         =>  $count_date
            ),
            array(
                'type'          =>  'dropdown',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'description'   =>  "",
                'heading'       =>  'Days',
                'param_name'    =>  'days',
                'value'         =>  $count_day
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'description'   =>  "import year by number eg: 2016",
                'heading'       =>  'Year',
                'param_name'    =>  'year',
                'value'         =>  '2016'
            ),
            array(
                'type'          =>  'textfield',
                'holder'        =>  'div',
                'admin_label'   =>  true,
                'description'   =>  "import year by number eg: 23:23:23",
                'heading'       =>  'Time',
                'param_name'    =>  'time',
                'value'         =>  '23:23:23'
            )
        )
    ))


?>